var testData = require('./../PO/datafile.json');
var moment = require('moment');
var AirbnbHomePage = function() {
    var EC = protractor.ExpectedConditions;
    
    var locationField = element(by.css("input[data-testid$='structured-search-input-field-query']"));
    var locationName = testData[0].locationFieldInput;
    var adultsCount = testData[0].numberOfAdults;
    var childrenCount = testData[0].numberOfChildren;
    var bedsCount = testData[0].bedsCount;
    var dateField = element(by.css("button[data-testid$='structured-search-input-field-split-dates-0']"));
    var startDate = moment().add(7, 'days').format('YYYY-MM-DD');
    var endDate = moment().add(14, 'days').format('YYYY-MM-DD');
    var startDateField = element(by.css("div[data-testid$='datepicker-day-"+ startDate +"']"));
    var endDateField = element(by.css("div[data-testid$='datepicker-day-"+ endDate +"']"));
    var guestField = element(by.css("button[data-testid$='structured-search-input-field-guests-button']"));
    var addAdultsButton = element(by.css("div[id$='stepper-adults'] button[aria-label$='increase value']"));
    var addChildrenButton = element(by.css("div[id$='stepper-children'] button[aria-label$='increase value']"));
    var searchButton = element(by.css("button[class$='_1mzhry13']"));
    var enteredStartDate = element(by.css("button[data-testid$='structured-search-input-field-split-dates-0'] div[class$='_vuaqekp']"));
    var enteredEndDate = element(by.css("button[data-testid$='structured-search-input-field-split-dates-1'] div[class$='_vuaqekp']"));
    var enteredGuests = element(by.css("button[data-testid$='structured-search-input-field-guests-button'] div[class$='_p4vcro6']"));
    var properties = element.all(by.css("div[itemprop$='itemListElement'] div[style$='margin-top: 9px;']"));
    var extraFilterButton = element(by.css("div[data-testid$='menuItemButton-dynamicMoreFilters']"));
    var addBedroomsButton = element(by.css("div[id$='filterItem-stepper-min_bedrooms-0'] button[aria-label$='increase value']"));
    var poolFacility = element(by.css("label[data-testid$='filterItem-checkbox-amenities-7']"));
    var showStaysButton = element(by.css("button[data-testid$='more-filters-modal-submit-button']"));
    var showAllAmenities = element(by.css("div[class$='_1tv4hg3'] a[class$='_13e0raay']"));
    var poolAmenity = element.all(by.css("div[class$='_vzrbjl']"));
    var pro = element.all(by.css("div[class$='_3gn0lkf'] a[class$='_gjfol0']"));

    

    this.get = function(url) {
        browser.get(url);
    };

    this.enter_location = async function() {
        locationField.sendKeys(locationName);
    };

    this.enter_start_and_end_date = async function() {
        dateField.click()
        startDateField.click()
        endDateField.click()
    };

    this.enter_guests = async function() {
        guestField.click();
        browser.wait(EC.elementToBeClickable(addAdultsButton), 3000);
        var i;
        for (i = 0; i < adultsCount; i++) {
            addAdultsButton.click();
        }

        browser.wait(EC.elementToBeClickable(addChildrenButton), 3000);
        var i;
        for (i = 0; i < childrenCount; i++) {
            addChildrenButton.click();
        }
        
    };

    this.entered_location = async function() {
        var location = locationField.getAttribute('value');
        return location;
    };
        
    this.entered_start_date = async function() {
        var start_date = enteredStartDate.getText();
        return start_date;
    };

    this.entered_end_date = async function() {
        var end_date = enteredEndDate.getText();
        return end_date;
    };

    this.get_start_date = async function() {
        var startDate = moment().add(7, 'days').format('MMM D');
        return startDate;
    };
    
    this.get_end_date = async function() {
        var endDate = moment().add(14, 'days').format('MMM D');
        return endDate;
    };

    this.entered_guests = async function() {
        var guests = enteredGuests.getText();
        return guests;
    };

    this.click_search_button = async function() {
        searchButton.click()
    };

    this.get_number_of_guests_accomodation = async function(n) {
        browser.wait(EC.presenceOf(properties, 4000));
        var guests_accomodation =  properties.get(n).getText().then(guests = function (text) {
            var a = text.substring(0,2);
            return a;      
        });
        return guests_accomodation;    
    };


    this.click_extra_filter = async function() {
        extraFilterButton.click();
    };

    this.add_beds = async function() {
        browser.wait(EC.elementToBeClickable(addBedroomsButton), 4000);
        var i;
        for (i = 0; i < bedsCount; i++) {
            await addBedroomsButton.click();
        }
    };

    this.click_pool_facility = async function() {
        browser.wait(EC.elementToBeClickable(poolFacility), 3000);
        await poolFacility.click();
    };

    this.click_show_stays = async function() {
        showStaysButton.click();
    };

    this.get_number_of_bedrooms = async function(n) {
        var number_of_bedrooms =  properties.get(n).getText().then(bedrooms = function (text) {
            var a = text.substr(11,2);
            return a;      
        });
        return number_of_bedrooms;    
    };


    this.click_property_details = async function() {
        browser.getWindowHandle().then(function(parentGUID){
		    browser.actions().click(properties.get(0)).perform();
		    browser.sleep(5000);
		    browser.getAllWindowHandles().then(function(allGUID){
		        for(let guid of allGUID){
			        if(guid !=parentGUID){
				        browser.switchTo().window(guid);
				        break;
			        }
		        }
                showAllAmenities.click();
                browser.driver.sleep(10000);

                var pool = poolAmenity.getText();
                expect(pool).toMatch('Pool');

		        browser.close();
		        browser.switchTo().window(parentGUID);
		        
            })
        })

    };

    this.hover_over_first_properties = async function() {
        return browser.actions().mouseMove(properties.get(0)).perform();
    };

    this.click_property_on_map = async function() {
        browser.driver.sleep(10000);
        var property_on_map = pro.get(0).getAttribute('aria-label').then(function (text) {
            console.log(text);
            browser.actions().click(element(by.css("div[data-veloute$='map/GoogleMap'] button[aria-label*='" + text + "']"))).perform();
        });
    };

};
  
module.exports = AirbnbHomePage