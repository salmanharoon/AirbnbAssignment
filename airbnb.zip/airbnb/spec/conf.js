exports.config = {
    directConnect: 'true',
    specs: ['spec.js'],
    onPrepare: function () {
        browser.ignoreSynchronization = true;
        browser.manage().window().maximize();
    },
    //capabilities: {
        //'browserName': 'firefox'
   // },
    jasmineNodeOpts: {
        defaultTimeoutInterval: 2440000
       }
    
  };

