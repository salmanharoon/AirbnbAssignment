var homePage = require('./../PO/airbnbPageObjects.js');
var testData = require('./../PO/datafile.json');
var airbnbPage = new homePage();
var totalGuests = parseInt(testData[0].numberOfAdults) + parseInt(testData[0].numberOfChildren)
describe('Verify that the results match the search criteria', function() {
  it('should get Airbnb homepage', function() {
    airbnbPage.get(testData[0].url);
  });

  it('should search Rome, Italy and select Rome, Italy from dropdown', async function() {
    await airbnbPage.enter_location();
});

  it('should enter start and end date', async function() {  
    await airbnbPage.enter_start_and_end_date();
  });

  it('should enter 2 adults and 1 child as guests', async function() {  
    await airbnbPage.enter_guests();
  });

  it('should verify entered location, entered start date, entered end date and entered guests', async function() {  
    expect(testData[0].locationFieldInput).toEqual(airbnbPage.entered_location());
    expect(airbnbPage.get_start_date()).toEqual(airbnbPage.entered_start_date());
    expect(airbnbPage.get_end_date()).toEqual(airbnbPage.entered_end_date());
    expect(totalGuests + ' guests').toEqual(airbnbPage.entered_guests());
  });

  it('should click the search button', async function() {  
    await airbnbPage.click_search_button();
  });

  it('should verify that the properties displayed on the first page can accommodate at least the selected number of guests', async function() { 
    var i;
    for (i = 0; i < testData[0].numberOfPropertiesDisplayedOnPage; i++) {
      
      expect(String(totalGuests) <= airbnbPage.get_number_of_guests_accomodation(i)).toEqual(true);
    }  
  });
});

describe('Verify that the results and details page match the extra filters', function() {
  it('should click extra filters', async function() {
    await airbnbPage.click_extra_filter();
  }); 

  it('should add 5 beds in extra filter', async function() {  
    await airbnbPage.add_beds();
  });

  it('should select pool facility', async function() {  
    await airbnbPage.click_pool_facility();
  });

  it('should click show stays button', async function() {  
    await airbnbPage.click_show_stays();
  });

  it('should verify that the properties displayed on the first page have at least the number of selected bedrooms', async function() { 
    var i;
    browser.driver.sleep(10000);
    for (i = 0; i < testData[0].numberOfPropertiesDisplayedOnPage; i++) {     
      expect(String(testData[0].bedsCount) <= airbnbPage.get_number_of_bedrooms(i)).toEqual(true);
    }
    
  });

  it('should open property details and verify that in the Amenities popup Pool is displayed under Facilities category', async function() {     
    await airbnbPage.click_property_details();
  });

  it('should Hover over the first property check that the property is displayed on the map and the color changes to indicate the selection', async function() {     
    expect(airbnbPage.hover_over_first_properties()).toBeTruthy();
    browser.driver.sleep(10000);
  });

  it('should click property on map', async function() {     
    await airbnbPage.click_property_on_map();
    browser.driver.sleep(10000);
  });
});